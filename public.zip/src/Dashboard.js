/**
 * BlueView GIS — Dashboard.jsx  (v3 — ArcGIS Dashboard Style)
 *
 * HOW IT WORKS (exactly like ArcGIS Dashboard):
 *   1. Left panel = flat list of widget types (Map, Serial chart, Indicator…)
 *   2. Click a widget → it goes on canvas → config dialog opens automatically
 *   3. Config dialog: Step 1 = pick your layer, Step 2 = configure fields
 *   4. Empty canvas by default — you build it yourself, any time
 *   5. "Elements" tab shows what's currently on canvas
 *
 * DEPENDENCIES:
 *   react-grid-layout ^1.4.4, recharts, @mui/material, @mui/icons-material
 */

import React, { useState, useEffect, useRef, useCallback, useMemo } from "react";

import {
  ResponsiveContainer, BarChart, Bar, XAxis, YAxis,
  CartesianGrid, Tooltip, PieChart, Pie, Cell,
} from "recharts";

import {
  Box, Paper, Typography, IconButton, Button, Chip, Divider,
  Dialog, DialogContent, DialogActions,
  TextField, Select, MenuItem, FormControl, InputLabel,
  Table, TableBody, TableCell, TableHead, TableRow,
  TablePagination, CircularProgress, Tooltip as MuiTooltip,
  Switch, FormControlLabel, Slider, Snackbar, Alert,
  LinearProgress, InputAdornment,
} from "@mui/material";

import {
  Close as CloseIcon, Settings as SettingsIcon,
  Refresh as RefreshIcon, Map as MapIcon, Layers as LayersIcon,
  DragIndicator as DragIcon, Save as SaveIcon, RestartAlt as ResetIcon,
  AdminPanelSettings as AdminIcon, Person as PersonIcon,
  Download as DownloadIcon, ArrowUpward as TrendUpIcon,
  ArrowDownward as TrendDownIcon, Remove as NeutralIcon,
  Delete as DeleteIcon, Add as AddIcon, Public as PortalIcon,
  Link as LinkIcon, InfoOutlined as DetailsIcon, OpenInNew as OpenIcon,
} from "@mui/icons-material";

// ─── react-grid-layout ───────────────────────────────────────────────────────
let GridLayout;
try {
  const rgl = require("react-grid-layout");
  const Base = rgl.default || rgl.Responsive || rgl;
  GridLayout = rgl.WidthProvider ? rgl.WidthProvider(Base) : Base;
} catch { GridLayout = null; }

// =============================================================================
// THEME
// =============================================================================
const C = {
  bg:"#F0F4F8", surface:"#FFFFFF", border:"#E2E8F0",
  primary:"#1565C0", accent:"#F59E0B", text:"#1E293B",
  muted:"#64748B", danger:"#DC2626", success:"#16A34A",
  warning:"#D97706", topbar:"#1A2035", purple:"#7C3AED", teal:"#0891B2",
};
const CHART_COLORS = ["#1565C0","#F59E0B","#16A34A","#7C3AED","#0891B2","#DC2626","#92400E","#475569"];

// =============================================================================
// WIDGET TYPES  (ordered exactly like screenshot)
// =============================================================================
const WIDGET_TYPES = {
  map:         { label:"Map",          minW:4,minH:4,defW:6,defH:5 },
  serialChart: { label:"Serial chart", minW:3,minH:3,defW:4,defH:3 },
  pieChart:    { label:"Pie chart",    minW:3,minH:3,defW:3,defH:3 },
  indicator:   { label:"Indicator",   minW:2,minH:2,defW:2,defH:2 },
  gauge:       { label:"Gauge",       minW:2,minH:2,defW:3,defH:3 },
  list:        { label:"List",        minW:2,minH:2,defW:3,defH:3 },
  table:       { label:"Table",       minW:4,minH:3,defW:6,defH:4 },
  details:     { label:"Details",     minW:2,minH:3,defW:3,defH:3 },
};
const WIDGET_ORDER = ["map","serialChart","pieChart","indicator","gauge","list","table","details"];
const REFRESH_OPT  = [{value:0,label:"Off"},{value:30000,label:"30 sec"},{value:60000,label:"1 min"},{value:300000,label:"5 min"}];

// =============================================================================
// LAYER REGISTRY  (mock Esri layers — replace with real REST API)
// =============================================================================
const LAYER_REGISTRY = {
  "GAS:pipeline_line":      { label:"Pipeline Lines",      group:"Gas Network" },
  "GAS:pipeline_device":    { label:"Pipeline Devices",    group:"Gas Network" },
  "GAS:pipeline_junction":  { label:"Pipeline Junctions",  group:"Gas Network" },
  "GAS:pipeline_assembly":  { label:"Pipeline Assembly",   group:"Gas Network" },
  "GAS:structure_boundary": { label:"Structure Boundary",  group:"Structures"  },
  "GAS:structure_junction": { label:"Structure Junctions", group:"Structures"  },
};

// =============================================================================
// MOCK DATA
// =============================================================================
const MOCK_DATA = {
  "GAS:pipeline_line":{ totalCount:1243,trend:5.2,
    fields:["material","diameter_mm","zone","status","length_m","year_installed"],
    features:[
      {properties:{material:"Steel",    diameter_mm:200,zone:"North",status:"Active",  length_m:1200,year_installed:2015}},
      {properties:{material:"HDPE",     diameter_mm:110,zone:"South",status:"Active",  length_m: 870,year_installed:2018}},
      {properties:{material:"Steel",    diameter_mm:300,zone:"East", status:"Inactive",length_m:2100,year_installed:2010}},
      {properties:{material:"HDPE",     diameter_mm: 63,zone:"West", status:"Active",  length_m: 430,year_installed:2020}},
      {properties:{material:"Cast Iron",diameter_mm:150,zone:"North",status:"Damaged", length_m: 980,year_installed:2005}},
      {properties:{material:"Steel",    diameter_mm:200,zone:"South",status:"Active",  length_m:1560,year_installed:2016}},
      {properties:{material:"HDPE",     diameter_mm:110,zone:"East", status:"Active",  length_m: 720,year_installed:2019}},
      {properties:{material:"Cast Iron",diameter_mm:100,zone:"West", status:"Inactive",length_m: 340,year_installed:2003}},
      {properties:{material:"Steel",    diameter_mm:400,zone:"North",status:"Active",  length_m:3200,year_installed:2012}},
      {properties:{material:"HDPE",     diameter_mm: 90,zone:"South",status:"Active",  length_m: 610,year_installed:2021}},
    ]},
  "GAS:pipeline_device":{ totalCount:387,trend:-1.8,
    fields:["device_type","zone","status","pressure_bar"],
    features:[
      {properties:{device_type:"Valve",        zone:"North",status:"Active",  pressure_bar:4.5}},
      {properties:{device_type:"Regulator",    zone:"South",status:"Active",  pressure_bar:3.2}},
      {properties:{device_type:"Meter",        zone:"East", status:"Active",  pressure_bar:2.1}},
      {properties:{device_type:"Valve",        zone:"West", status:"Inactive",pressure_bar:0.0}},
      {properties:{device_type:"Safety Relief",zone:"North",status:"Active",  pressure_bar:6.0}},
      {properties:{device_type:"Regulator",    zone:"East", status:"Damaged", pressure_bar:1.8}},
      {properties:{device_type:"Meter",        zone:"South",status:"Active",  pressure_bar:2.5}},
      {properties:{device_type:"Valve",        zone:"North",status:"Active",  pressure_bar:4.0}},
    ]},
  "GAS:pipeline_junction":{ totalCount:892,trend:0.4,
    fields:["junction_type","zone","material","status"],
    features:[
      {properties:{junction_type:"T-Junction",zone:"North",material:"Steel",    status:"Active"  }},
      {properties:{junction_type:"Elbow",     zone:"South",material:"HDPE",     status:"Active"  }},
      {properties:{junction_type:"Cross",     zone:"East", material:"Steel",    status:"Active"  }},
      {properties:{junction_type:"T-Junction",zone:"West", material:"Cast Iron",status:"Inactive"}},
      {properties:{junction_type:"Reducer",   zone:"North",material:"Steel",    status:"Active"  }},
      {properties:{junction_type:"Elbow",     zone:"East", material:"HDPE",     status:"Damaged" }},
    ]},
  "GAS:pipeline_assembly":{ totalCount:156,trend:2.1,
    fields:["assembly_type","zone","material","status","pressure_bar"],
    features:[
      {properties:{assembly_type:"Above Ground",zone:"North",material:"Steel",status:"Active", pressure_bar:7.0}},
      {properties:{assembly_type:"Underground", zone:"South",material:"HDPE", status:"Active", pressure_bar:4.5}},
      {properties:{assembly_type:"Above Ground",zone:"East", material:"Steel",status:"Damaged",pressure_bar:5.2}},
      {properties:{assembly_type:"Underground", zone:"West", material:"HDPE", status:"Active", pressure_bar:3.8}},
    ]},
  "GAS:structure_boundary":{ totalCount:48,trend:0,
    fields:["boundary_type","area_sqm","status"],
    features:[
      {properties:{boundary_type:"Zone A",area_sqm:12000,status:"Active"  }},
      {properties:{boundary_type:"Zone B",area_sqm: 8500,status:"Active"  }},
      {properties:{boundary_type:"Zone C",area_sqm:15000,status:"Active"  }},
      {properties:{boundary_type:"Zone D",area_sqm: 6200,status:"Inactive"}},
    ]},
  "GAS:structure_junction":{ totalCount:274,trend:3.0,
    fields:["type","zone","status","capacity"],
    features:[
      {properties:{type:"Primary",  zone:"North",status:"Active",  capacity:"High"  }},
      {properties:{type:"Secondary",zone:"South",status:"Active",  capacity:"Medium"}},
      {properties:{type:"Primary",  zone:"East", status:"Inactive",capacity:"Low"   }},
      {properties:{type:"Secondary",zone:"West", status:"Active",  capacity:"High"  }},
      {properties:{type:"Tertiary", zone:"North",status:"Damaged", capacity:"Low"   }},
    ]},
};

function groupByField(features,field){
  const c={};
  features.forEach(f=>{const v=f.properties[field];if(v!=null)c[String(v)]=(c[String(v)]||0)+1;});
  return Object.entries(c).map(([name,value])=>({name,value}));
}
function fetchLayerData(key){
  return new Promise(res=>setTimeout(()=>res(MOCK_DATA[key]?{...MOCK_DATA[key]}:{totalCount:0,trend:0,fields:[],features:[]}),300));
}
function detectRestFields(url){
  return new Promise(res=>setTimeout(()=>{
    if(!url||!url.startsWith("http"))return res({ok:false,error:"Enter a valid https:// URL"});
    res({ok:true,count:Math.floor(Math.random()*2000)+50,
      fields:["OBJECTID","GlobalID","status","material","zone","diameter_mm","length_m","year_installed","pressure_bar","device_type"]});
  },1200));
}

// =============================================================================
// HOOKS
// =============================================================================
function useInterval(cb,delay){
  const r=useRef(cb);
  useEffect(()=>{r.current=cb;},[cb]);
  useEffect(()=>{if(!delay)return;const id=setInterval(()=>r.current(),delay);return()=>clearInterval(id);},[delay]);
}
function useLS(key,init){
  const[v,setV]=useState(()=>{try{const s=localStorage.getItem(key);return s?JSON.parse(s):init;}catch{return init;}});
  const set=val=>{const next=typeof val==="function"?val(v):val;setV(next);try{localStorage.setItem(key,JSON.stringify(next));}catch{}};
  return[v,set];
}

// =============================================================================
// SVG ICONS  — stroke-based, matching ArcGIS panel style
// =============================================================================
function WIcon({type,size=18,color="#6B7280"}){
  const p={width:size,height:size,viewBox:"0 0 24 24",fill:"none",stroke:color,strokeWidth:"1.7",strokeLinecap:"round",strokeLinejoin:"round"};
  if(type==="map")         return <svg {...p}><polygon points="3 6 9 3 15 6 21 3 21 18 15 21 9 18 3 21"/><line x1="9" y1="3" x2="9" y2="18"/><line x1="15" y1="6" x2="15" y2="21"/></svg>;
  if(type==="serialChart") return <svg {...p}><rect x="3" y="12" width="4" height="8" fill={color} stroke="none" rx="1"/><rect x="10" y="7" width="4" height="13" fill={color} stroke="none" rx="1"/><rect x="17" y="4" width="4" height="16" fill={color} stroke="none" rx="1"/></svg>;
  if(type==="pieChart")    return <svg {...p}><path d="M21.21 15.89A10 10 0 1 1 8 2.83"/><path d="M22 12A10 10 0 0 0 12 2v10z"/></svg>;
  if(type==="indicator")   return <svg {...p}><text x="2" y="17" fontSize="13" fontWeight="bold" fill={color} stroke="none">99!</text></svg>;
  if(type==="gauge")       return <svg {...p}><path d="M12 22C6.477 22 2 17.523 2 12S6.477 2 12 2s10 4.477 10 10"/><path d="m12 12-4-2"/><circle cx="12" cy="12" r="1.5" fill={color} stroke="none"/></svg>;
  if(type==="list")        return <svg {...p}><line x1="8" y1="6" x2="21" y2="6"/><line x1="8" y1="12" x2="21" y2="12"/><line x1="8" y1="18" x2="21" y2="18"/><circle cx="3" cy="6" r="1" fill={color} stroke="none"/><circle cx="3" cy="12" r="1" fill={color} stroke="none"/><circle cx="3" cy="18" r="1" fill={color} stroke="none"/></svg>;
  if(type==="table")       return <svg {...p}><rect x="3" y="3" width="18" height="18" rx="2"/><line x1="3" y1="9" x2="21" y2="9"/><line x1="3" y1="15" x2="21" y2="15"/><line x1="9" y1="9" x2="9" y2="21"/></svg>;
  if(type==="details")     return <svg {...p}><rect x="3" y="3" width="18" height="18" rx="2"/><line x1="3" y1="9" x2="21" y2="9"/><line x1="9" y1="9" x2="9" y2="21"/><line x1="13" y1="13" x2="17" y2="13"/><line x1="13" y1="17" x2="17" y2="17"/></svg>;
  return null;
}

// =============================================================================
// WIDGET RENDERERS
// =============================================================================
const FC={display:"flex",justifyContent:"center",alignItems:"center",height:"100%"};

function IndicatorWidget({config,data,loading}){
  const val=data?.totalCount??0,trend=data?.trend??0,col=config.color||C.primary;
  const TI=trend>0?TrendUpIcon:trend<0?TrendDownIcon:NeutralIcon;
  const tc=trend>0?C.success:trend<0?C.danger:C.muted;
  if(loading)return<Box sx={FC}><CircularProgress size={24} sx={{color:col}}/></Box>;
  return(
    <Box sx={{...FC,flexDirection:"column",gap:.5}}>
      <Typography sx={{fontSize:"2.6rem",fontWeight:800,color:col,lineHeight:1,letterSpacing:"-2px"}}>{val.toLocaleString()}</Typography>
      {config.unit&&<Typography sx={{fontSize:10,color:C.muted,textTransform:"uppercase",letterSpacing:1.5,fontWeight:600}}>{config.unit}</Typography>}
      {trend!==0&&<Box sx={{display:"flex",alignItems:"center",gap:.3,mt:.5,px:1,py:.3,borderRadius:8,bgcolor:trend>0?"#DCFCE7":"#FEE2E2"}}><TI sx={{fontSize:11,color:tc}}/><Typography sx={{fontSize:11,color:tc,fontWeight:700}}>{Math.abs(trend).toFixed(1)}%</Typography></Box>}
    </Box>
  );
}

function SerialChartWidget({config,data,loading}){
  const chartData=useMemo(()=>data?.features?groupByField(data.features,config.groupByField):[],[data,config.groupByField]);
  if(loading)return<Box sx={FC}><CircularProgress size={22}/></Box>;
  if(!chartData.length)return<Box sx={{...FC,color:C.muted}}><Typography variant="body2">No data</Typography></Box>;
  return(
    <ResponsiveContainer width="100%" height="100%">
      <BarChart data={chartData} margin={{top:4,right:8,left:-18,bottom:4}}>
        <CartesianGrid strokeDasharray="3 3" stroke="#F1F5F9" vertical={false}/>
        <XAxis dataKey="name" tick={{fontSize:11,fill:C.muted}} axisLine={false} tickLine={false}/>
        <YAxis tick={{fontSize:10,fill:C.muted}} axisLine={false} tickLine={false}/>
        <Tooltip contentStyle={{fontSize:12,borderRadius:8,border:"none",boxShadow:"0 4px 20px rgba(0,0,0,.12)"}} cursor={{fill:"rgba(21,101,192,.05)"}}/>
        <Bar dataKey="value" radius={[4,4,0,0]}>{chartData.map((_,i)=><Cell key={i} fill={CHART_COLORS[i%CHART_COLORS.length]}/>)}</Bar>
      </BarChart>
    </ResponsiveContainer>
  );
}

function PieChartWidget({config,data,loading}){
  const chartData=useMemo(()=>data?.features?groupByField(data.features,config.groupByField):[],[data,config.groupByField]);
  const[active,setActive]=useState(null);
  const total=chartData.reduce((s,d)=>s+d.value,0);
  if(loading)return<Box sx={FC}><CircularProgress size={22}/></Box>;
  if(!chartData.length)return<Box sx={{...FC,color:C.muted}}><Typography variant="body2">No data</Typography></Box>;
  return(
    <Box sx={{height:"100%",display:"flex",flexDirection:"column"}}>
      <ResponsiveContainer width="100%" height="72%">
        <PieChart>
          <Pie data={chartData} cx="50%" cy="50%" innerRadius={config.donut?"50%":"0%"} outerRadius="82%" dataKey="value" stroke="none" onMouseEnter={(_,i)=>setActive(i)} onMouseLeave={()=>setActive(null)}>
            {chartData.map((_,i)=><Cell key={i} fill={CHART_COLORS[i%CHART_COLORS.length]} opacity={active===null||active===i?1:.5}/>)}
          </Pie>
          <Tooltip contentStyle={{fontSize:12,borderRadius:8,border:"none",boxShadow:"0 4px 20px rgba(0,0,0,.12)"}} formatter={v=>[`${v} (${((v/total)*100).toFixed(1)}%)`,""]}/>
        </PieChart>
      </ResponsiveContainer>
      <Box sx={{display:"flex",flexWrap:"wrap",gap:.8,px:1.5,overflow:"auto"}}>
        {chartData.map((d,i)=>(
          <Box key={i} sx={{display:"flex",alignItems:"center",gap:.4}}>
            <Box sx={{width:8,height:8,borderRadius:2,bgcolor:CHART_COLORS[i%CHART_COLORS.length],flexShrink:0}}/>
            <Typography sx={{fontSize:10,color:C.muted}}>{d.name} ({((d.value/total)*100).toFixed(0)}%)</Typography>
          </Box>
        ))}
      </Box>
    </Box>
  );
}

function GaugeWidget({config,data,loading}){
  const pct=useMemo(()=>{if(!data?.features?.length)return 0;const m=data.features.filter(f=>String(f.properties[config.field])===String(config.matchValue)).length;return Math.round((m/data.features.length)*100);},[data,config]);
  const color=pct<=(config.thresholdDanger||40)?C.danger:pct<=(config.thresholdWarning||60)?C.warning:C.success;
  const R=52,CX=70,CY=72,s=-210,e=30,tot=e-s;
  const norm=((pct-(config.gaugeMin||0))/((config.gaugeMax||100)-(config.gaugeMin||0)))*100;
  const tr=d=>(d*Math.PI)/180;
  const arc=(f,t,r)=>{const x1=CX+r*Math.cos(tr(f)),y1=CY+r*Math.sin(tr(f)),x2=CX+r*Math.cos(tr(t)),y2=CY+r*Math.sin(tr(t));return`M ${x1} ${y1} A ${r} ${r} 0 ${t-f>180?1:0} 1 ${x2} ${y2}`;};
  const na=s+(tot*norm)/100,nx=CX+45*Math.cos(tr(na)),ny=CY+45*Math.sin(tr(na));
  if(loading)return<Box sx={FC}><CircularProgress size={22}/></Box>;
  return(
    <Box sx={{...FC,flexDirection:"column",height:"100%"}}>
      <svg viewBox="0 0 140 100" style={{width:"100%",maxWidth:190}}>
        <path d={arc(s,e,R)} fill="none" stroke="#F1F5F9" strokeWidth="14" strokeLinecap="round"/>
        <path d={arc(s,s+tot*.4,R)} fill="none" stroke="#FEE2E2" strokeWidth="14" strokeLinecap="round"/>
        <path d={arc(s+tot*.4,s+tot*.6,R)} fill="none" stroke="#FEF9C3" strokeWidth="14" strokeLinecap="round"/>
        <path d={arc(s,s+(tot*norm)/100,R)} fill="none" stroke={color} strokeWidth="14" strokeLinecap="round"/>
        <line x1={CX} y1={CY} x2={nx} y2={ny} stroke="#1E293B" strokeWidth="2.5" strokeLinecap="round"/>
        <circle cx={CX} cy={CY} r="5" fill="#1E293B"/>
        <text x={CX} y={CY+22} textAnchor="middle" fontSize="18" fontWeight="800" fill={color}>{pct}{config.unit||"%"}</text>
        <text x="16" y="92" fontSize="8" fill="#94A3B8">{config.gaugeMin||0}</text>
        <text x="124" y="92" fontSize="8" fill="#94A3B8" textAnchor="end">{config.gaugeMax||100}</text>
      </svg>
      <Typography sx={{fontSize:10,color:C.muted}}>{config.matchValue} / total</Typography>
    </Box>
  );
}

function TableWidget({config,data,loading}){
  const[page,setPage]=useState(0);const[search,setSearch]=useState("");
  const ps=config.pageSize||5;
  const cols=config.columns?.length?config.columns:Object.keys(data?.features?.[0]?.properties||{});
  const rows=useMemo(()=>{const all=(data?.features||[]).map(f=>f.properties);if(!search)return all;return all.filter(r=>cols.some(c=>String(r[c]??"").toLowerCase().includes(search.toLowerCase())));},[data,cols,search]);
  const exportCSV=()=>{const csv=[cols.join(","),...rows.map(r=>cols.map(c=>`"${r[c]??""}"` ).join(","))].join("\n");const a=document.createElement("a");a.href=URL.createObjectURL(new Blob([csv],{type:"text/csv"}));a.download=`${config.title||"data"}.csv`;a.click();};
  const sc=v=>{const s=String(v||"").toLowerCase();if(s==="active")return{color:C.success,bg:"#DCFCE7"};if(s==="inactive")return{color:"#78350F",bg:"#FEF3C7"};if(s==="damaged")return{color:C.danger,bg:"#FEE2E2"};return null;};
  if(loading)return<Box sx={FC}><CircularProgress size={22}/></Box>;
  return(
    <Box sx={{display:"flex",flexDirection:"column",height:"100%"}}>
      <Box sx={{display:"flex",gap:1,px:1.5,pt:1,pb:.5,alignItems:"center"}}>
        {config.searchable&&<TextField size="small" placeholder="Search…" value={search} onChange={e=>{setSearch(e.target.value);setPage(0);}} sx={{flex:1,"& .MuiInputBase-root":{fontSize:12,height:28,borderRadius:2}}}/>}
        {config.exportable&&<MuiTooltip title="Export CSV"><IconButton size="small" onClick={exportCSV} sx={{color:C.primary}}><DownloadIcon sx={{fontSize:16}}/></IconButton></MuiTooltip>}
        <Typography sx={{fontSize:11,color:C.muted,whiteSpace:"nowrap"}}>{rows.length} rows</Typography>
      </Box>
      <Box sx={{flex:1,overflow:"auto"}}>
        <Table size="small" stickyHeader>
          <TableHead><TableRow>{cols.map(c=><TableCell key={c} sx={{bgcolor:"#F8FAFC",fontWeight:700,fontSize:10,py:.7,whiteSpace:"nowrap",color:C.muted,textTransform:"uppercase",letterSpacing:.8,borderBottom:`2px solid ${C.border}`}}>{c.replace(/_/g," ")}</TableCell>)}</TableRow></TableHead>
          <TableBody>{rows.slice(page*ps,page*ps+ps).map((row,i)=><TableRow key={i} sx={{"&:hover":{bgcolor:"#F8FAFC"}}}>{cols.map(col=>{const v=row[col],chip=col==="status"?sc(v):null;return<TableCell key={col} sx={{fontSize:12,py:.5,borderBottom:`1px solid #F1F5F9`,whiteSpace:"nowrap"}}>{chip?<Chip label={String(v)} size="small" sx={{fontSize:10,height:18,fontWeight:700,color:chip.color,bgcolor:chip.bg}}/>:(v!=null?String(v):"—")}</TableCell>;})}</TableRow>)}</TableBody>
        </Table>
      </Box>
      <TablePagination component="div" count={rows.length} page={page} onPageChange={(_,p)=>setPage(p)} rowsPerPage={ps} rowsPerPageOptions={[ps]} sx={{"& .MuiTablePagination-toolbar":{minHeight:34},"& *":{fontSize:"11px !important"}}}/>
    </Box>
  );
}

function ListWidget({config,data,loading}){
  const rows=useMemo(()=>(data?.features||[]).slice(0,10).map(f=>f.properties),[data]);
  const field=config.groupByField||Object.keys(rows[0]||{})[0]||"name";
  if(loading)return<Box sx={FC}><CircularProgress size={22}/></Box>;
  return(
    <Box sx={{height:"100%",overflow:"auto"}}>
      {rows.map((r,i)=>(
        <Box key={i} sx={{display:"flex",alignItems:"center",gap:1.5,px:1.5,py:.7,borderBottom:`1px solid ${C.border}`,"&:hover":{bgcolor:"#F8FAFC"}}}>
          <Box sx={{width:22,height:22,borderRadius:1,bgcolor:`${CHART_COLORS[i%CHART_COLORS.length]}20`,display:"flex",alignItems:"center",justifyContent:"center",flexShrink:0}}><Typography sx={{fontSize:10,fontWeight:700,color:CHART_COLORS[i%CHART_COLORS.length]}}>{i+1}</Typography></Box>
          <Typography sx={{fontSize:12,color:C.text,flex:1}}>{r[field]||"—"}</Typography>
          {r.status&&<Chip label={r.status} size="small" sx={{fontSize:9,height:16,color:r.status==="Active"?C.success:r.status==="Damaged"?C.danger:C.muted,bgcolor:r.status==="Active"?"#DCFCE7":r.status==="Damaged"?"#FEE2E2":"#F1F5F9"}}/>}
        </Box>
      ))}
    </Box>
  );
}

function DetailsWidget({config,data,loading}){
  const[selIdx,setSelIdx]=useState(0);
  const features=data?.features||[],feat=features[selIdx],props=feat?.properties||{};
  const displayFields=config.detailFields?.length?config.detailFields:Object.keys(props);
  const sc=v=>{const s=String(v||"").toLowerCase();if(s==="active")return{color:C.success,bg:"#DCFCE7"};if(s==="inactive")return{color:"#78350F",bg:"#FEF3C7"};if(s==="damaged")return{color:C.danger,bg:"#FEE2E2"};return null;};
  if(loading)return<Box sx={FC}><CircularProgress size={22}/></Box>;
  if(!features.length)return<Box sx={{...FC,flexDirection:"column",gap:.5}}><DetailsIcon sx={{color:C.border,fontSize:32}}/><Typography sx={{fontSize:12,color:C.muted}}>No features</Typography></Box>;
  return(
    <Box sx={{height:"100%",display:"flex",flexDirection:"column"}}>
      <Box sx={{display:"flex",gap:.5,px:1.5,pt:1,pb:.5,alignItems:"center",flexShrink:0}}>
        <Typography sx={{fontSize:11,color:C.muted}}>Feature:</Typography>
        <Select value={selIdx} onChange={e=>setSelIdx(e.target.value)} size="small" sx={{flex:1,fontSize:12,"& .MuiSelect-select":{py:.3}}}>
          {features.map((_,i)=><MenuItem key={i} value={i} sx={{fontSize:12}}>Record {i+1}</MenuItem>)}
        </Select>
      </Box>
      <Box sx={{flex:1,overflow:"auto"}}>
        {displayFields.map(k=>{const v=props[k],chip=k==="status"?sc(v):null;return(
          <Box key={k} sx={{display:"flex",px:1.5,py:.6,borderBottom:`1px solid #F8FAFC`,"&:hover":{bgcolor:"#FAFBFC"}}}>
            <Typography sx={{fontSize:11,color:C.muted,textTransform:"uppercase",letterSpacing:.6,fontWeight:600,width:"45%",flexShrink:0}}>{k.replace(/_/g," ")}</Typography>
            {chip?<Chip label={String(v)} size="small" sx={{fontSize:10,height:18,fontWeight:700,color:chip.color,bgcolor:chip.bg}}/>:<Typography sx={{fontSize:12,color:C.text}}>{v!=null?String(v):"—"}</Typography>}
          </Box>
        );})}
      </Box>
    </Box>
  );
}

function MapWidget({config}){
  const url=config.mapUrl||"",hasUrl=url.startsWith("http");
  return(
    <Box sx={{height:"100%",position:"relative",overflow:"hidden",bgcolor:"#EBF2FA",borderRadius:1}}>
      {hasUrl?(
        <iframe src={url} title={config.title||"Map"} style={{width:"100%",height:"100%",border:"none",display:"block"}} allowFullScreen referrerPolicy="no-referrer"/>
      ):(
        <Box sx={{...FC,flexDirection:"column",gap:1.5,height:"100%"}}>
          <svg width="80" height="80" viewBox="0 0 80 80" fill="none"><circle cx="40" cy="40" r="39" fill="#DBEAFE" stroke="#BFDBFE" strokeWidth="1.5"/><path d="M20 58 L30 26 L48 44 L58 22 L70 58Z" fill="#EFF6FF" stroke="#93C5FD" strokeWidth="1.5"/><path d="M30 26 L48 44 L58 22" stroke={C.primary} strokeWidth="2" fill="none" strokeLinecap="round"/><circle cx="30" cy="26" r="4" fill={C.primary}/><circle cx="58" cy="22" r="4" fill={C.accent}/></svg>
          <Box sx={{textAlign:"center"}}><Typography sx={{fontSize:12,fontWeight:700,color:C.text}}>Map widget</Typography><Typography sx={{fontSize:11,color:C.muted,mt:.4}}>Set embed URL in ⚙ settings</Typography></Box>
        </Box>
      )}
      {hasUrl&&<Box sx={{position:"absolute",bottom:8,right:8}}><IconButton size="small" onClick={()=>window.open(url,"_blank")} sx={{bgcolor:"rgba(255,255,255,.9)",boxShadow:"0 2px 8px rgba(0,0,0,.15)"}}><OpenIcon sx={{fontSize:14,color:C.primary}}/></IconButton></Box>}
    </Box>
  );
}

// =============================================================================
// WIDGET CARD SHELL
// =============================================================================
function WidgetCard({config,loading,isAdmin,onEdit,onDelete,onRefresh,lastRefreshed,children}){
  const accent={serialChart:C.primary,pieChart:C.purple,indicator:C.accent,gauge:C.warning,table:"#475569",list:C.teal,map:"#16803C",details:"#0F766E"}[config.type]||C.primary;
  return(
    <Paper elevation={0} sx={{height:"100%",display:"flex",flexDirection:"column",border:`1px solid ${C.border}`,borderRadius:"10px",overflow:"hidden",bgcolor:C.surface,transition:"box-shadow .2s,border-color .2s","&:hover":{boxShadow:"0 4px 24px rgba(0,0,0,.08)",borderColor:"#C7D7ED"}}}>
      <Box sx={{display:"flex",alignItems:"center",px:1.5,py:.8,borderBottom:`1px solid ${C.border}`,minHeight:38,gap:.8,flexShrink:0}}>
        <Box sx={{width:3,height:18,bgcolor:accent,borderRadius:4,flexShrink:0}}/>
        {isAdmin&&<DragIcon className="drag-handle" sx={{fontSize:15,color:"#CBD5E1",cursor:"grab",flexShrink:0,"&:hover":{color:"#94A3B8"}}}/>}
        <Typography sx={{fontSize:12,fontWeight:700,color:C.text,flex:1,overflow:"hidden",textOverflow:"ellipsis",whiteSpace:"nowrap"}}>{config.title||WIDGET_TYPES[config.type]?.label||"Widget"}</Typography>
        {loading&&<CircularProgress size={11} sx={{color:accent}}/>}
        {config.layerLabel&&<Chip label={config.layerLabel} size="small" sx={{fontSize:9,height:17,bgcolor:"#EFF6FF",color:C.primary,fontWeight:600,maxWidth:110,"& .MuiChip-label":{overflow:"hidden",textOverflow:"ellipsis"}}}/>}
        {!loading&&lastRefreshed&&<Typography sx={{fontSize:9,color:"#CBD5E1"}}>{new Date(lastRefreshed).toLocaleTimeString([],{hour:"2-digit",minute:"2-digit"})}</Typography>}
        {config.type!=="map"&&<MuiTooltip title="Refresh"><IconButton size="small" onClick={onRefresh} sx={{p:.3,color:"#CBD5E1","&:hover":{color:accent}}}><RefreshIcon sx={{fontSize:13}}/></IconButton></MuiTooltip>}
        {isAdmin&&<><MuiTooltip title="Configure"><IconButton size="small" onClick={onEdit} sx={{p:.3,color:"#CBD5E1","&:hover":{color:C.primary}}}><SettingsIcon sx={{fontSize:13}}/></IconButton></MuiTooltip><MuiTooltip title="Remove"><IconButton size="small" onClick={onDelete} sx={{p:.3,color:"#CBD5E1","&:hover":{color:C.danger}}}><CloseIcon sx={{fontSize:13}}/></IconButton></MuiTooltip></>}
      </Box>
      <Box sx={{flex:1,overflow:"hidden",p:["table","list","details"].includes(config.type)?0:1.5}}>{children}</Box>
    </Paper>
  );
}

// =============================================================================
// MANAGED WIDGET
// =============================================================================
function ManagedWidget({widgetId,config,isAdmin,onEdit,onDelete}){
  const[data,setData]=useState(null);
  const[loading,setLoading]=useState(true);
  const[ts,setTs]=useState(null);
  const load=useCallback(async()=>{if(!config.layer||config.type==="map")return setLoading(false);setLoading(true);try{const r=await fetchLayerData(config.layer);setData(r);setTs(Date.now());}finally{setLoading(false);}},[ config.layer,config.type]);
  useEffect(()=>{load();},[load]);
  useInterval(load,config.refreshInterval||0);
  const inner=()=>{switch(config.type){case"indicator":return<IndicatorWidget config={config} data={data} loading={loading}/>;case"serialChart":return<SerialChartWidget config={config} data={data} loading={loading}/>;case"pieChart":return<PieChartWidget config={config} data={data} loading={loading}/>;case"gauge":return<GaugeWidget config={config} data={data} loading={loading}/>;case"table":return<TableWidget config={config} data={data} loading={loading}/>;case"list":return<ListWidget config={config} data={data} loading={loading}/>;case"details":return<DetailsWidget config={config} data={data} loading={loading}/>;case"map":return<MapWidget config={config}/>;default:return null;}};
  return<WidgetCard config={config} loading={loading} isAdmin={isAdmin} onEdit={onEdit} onDelete={onDelete} onRefresh={load} lastRefreshed={ts}>{inner()}</WidgetCard>;
}

// =============================================================================
// CONFIG DIALOG — Data Source tab first (layer picker), then Options, Refresh
// =============================================================================
function ConfigDialog({open,config,onClose,onSave,portals}){
  const[lc,setLc]=useState(config||{});
  const[tab,setTab]=useState(0);
  const[restUrl,setRestUrl]=useState("");
  const[detecting,setDetecting]=useState(false);
  const[detected,setDetected]=useState(null);
  const[detErr,setDetErr]=useState("");

  useEffect(()=>{setLc(config||{});setTab(0);setRestUrl(config?.layerUrl||"");setDetected(null);setDetErr("");},[config,open]);
  const upd=(k,v)=>setLc(p=>({...p,[k]:v}));

  const allLayers=useMemo(()=>{const out={...LAYER_REGISTRY};portals.forEach(p=>(p.layers||[]).forEach(l=>{out[`${p.id}:${l.name}`]={label:l.name,group:p.name};}));return out;},[portals]);
  const fields=useMemo(()=>{if(detected?.fields?.length)return detected.fields;return MOCK_DATA[lc.layer]?.fields||[];},[lc.layer,detected]);

  const handleDetect=async()=>{setDetecting(true);setDetected(null);setDetErr("");const r=await detectRestFields(restUrl);setDetecting(false);if(r.ok){setDetected(r);upd("layer",`custom:${Date.now()}`);upd("layerLabel",restUrl.split("/").slice(-3,-1).join("/")||"Custom layer");upd("layerUrl",restUrl);upd("detectedFields",r.fields);}else setDetErr(r.error);};

  const needsLayer=config?.type!=="map";
  const hasLayer=!!lc.layer;
  const isNew=!config?.layer;
  const TABS=["Data Source","Options","Refresh"];

  // Layer groups
  const layerGroups=Object.entries(allLayers).reduce((g,[k,v])=>{(g[v.group]=g[v.group]||[]).push([k,v]);return g;},{});

  return(
    <Dialog open={open} onClose={onClose} maxWidth="sm" fullWidth PaperProps={{sx:{borderRadius:3,overflow:"hidden"}}}>

      {/* Header */}
      <Box sx={{bgcolor:C.topbar,color:"white",px:2.5,py:1.5,display:"flex",justifyContent:"space-between",alignItems:"center"}}>
        <Box sx={{display:"flex",alignItems:"center",gap:1.5}}>
          <Box sx={{width:34,height:34,borderRadius:1.5,bgcolor:"rgba(255,255,255,.12)",display:"flex",alignItems:"center",justifyContent:"center"}}><WIcon type={lc.type} size={18} color="white"/></Box>
          <Box><Typography sx={{fontWeight:700,fontSize:14}}>{WIDGET_TYPES[lc.type]?.label||"Widget"}</Typography><Typography sx={{fontSize:11,opacity:.65}}>{isNew?"Choose a layer to get started":lc.title||"Configure"}</Typography></Box>
        </Box>
        <IconButton onClick={onClose} size="small" sx={{color:"white"}}><CloseIcon/></IconButton>
      </Box>

      {/* Tabs */}
      <Box sx={{display:"flex",borderBottom:`1px solid ${C.border}`,bgcolor:"#FAFBFC"}}>
        {TABS.map((t,i)=>(
          <Box key={t} onClick={()=>setTab(i)} sx={{px:2.5,py:1.2,fontSize:12,fontWeight:600,cursor:"pointer",color:tab===i?C.primary:C.muted,borderBottom:tab===i?`2px solid ${C.primary}`:"2px solid transparent",position:"relative"}}>
            {t}
            {t==="Data Source"&&needsLayer&&!hasLayer&&<Box sx={{position:"absolute",top:8,right:5,width:6,height:6,borderRadius:"50%",bgcolor:C.danger}}/>}
          </Box>
        ))}
      </Box>

      <DialogContent sx={{p:0,minHeight:360}}>

        {/* ── DATA SOURCE ─────────────────────────────────── */}
        {tab===0&&(
          <Box sx={{p:2.5,display:"flex",flexDirection:"column",gap:2}}>
            <TextField label="Widget title" value={lc.title||""} onChange={e=>upd("title",e.target.value)} size="small" fullWidth/>

            {lc.type==="map"&&(
              <TextField label="Map embed URL" value={lc.mapUrl||""} onChange={e=>upd("mapUrl",e.target.value)} size="small" fullWidth placeholder="https://your-portal/webapps/embed/..."/>
            )}

            {needsLayer&&(<>
              {/* Step 1 */}
              <Box sx={{display:"flex",alignItems:"center",gap:1}}>
                <Box sx={{width:22,height:22,borderRadius:"50%",flexShrink:0,bgcolor:hasLayer?"#DCFCE7":"#FEE2E2",display:"flex",alignItems:"center",justifyContent:"center"}}>
                  <Typography sx={{fontSize:11,fontWeight:800,color:hasLayer?C.success:C.danger}}>1</Typography>
                </Box>
                <Typography sx={{fontSize:12,fontWeight:700,color:C.text}}>Select layer from your map</Typography>
                {hasLayer&&<Chip label="✓ Selected" size="small" sx={{height:18,fontSize:9,bgcolor:"#DCFCE7",color:C.success,fontWeight:700}}/>}
              </Box>

              {/* Layer dropdown */}
              <FormControl size="small" fullWidth>
                <InputLabel>Choose layer</InputLabel>
                <Select value={lc.layer||""} label="Choose layer"
                  onChange={e=>{upd("layer",e.target.value);upd("layerLabel",allLayers[e.target.value]?.label||"");upd("groupByField","");upd("field","");upd("matchValue","");upd("detailFields",[]);upd("columns",[]);}}>
                  {Object.entries(layerGroups).map(([grp,items])=>[
                    <MenuItem key={grp} disabled sx={{fontSize:10,fontWeight:700,color:"#9CA3AF",textTransform:"uppercase",letterSpacing:.8,opacity:"1 !important",bgcolor:"#F9FAFB",py:.6}}>— {grp} —</MenuItem>,
                    ...items.map(([k,v])=>(
                      <MenuItem key={k} value={k} sx={{pl:3,py:.8}}>
                        <Box sx={{display:"flex",alignItems:"center",gap:1.5}}>
                          <LayersIcon sx={{fontSize:14,color:"#9CA3AF"}}/>
                          <Box><Typography sx={{fontSize:13}}>{v.label}</Typography><Typography sx={{fontSize:10,color:"#9CA3AF"}}>{k}</Typography></Box>
                        </Box>
                      </MenuItem>
                    )),
                  ])}
                </Select>
              </FormControl>

              {/* OR REST URL */}
              <Box sx={{display:"flex",alignItems:"center",gap:1}}><Divider sx={{flex:1}}/><Typography sx={{fontSize:10,color:"#9CA3AF",px:1}}>or paste Esri REST URL</Typography><Divider sx={{flex:1}}/></Box>
              <Box sx={{display:"flex",gap:1}}>
                <TextField size="small" value={restUrl} onChange={e=>setRestUrl(e.target.value)}
                  placeholder="https://gis.company.com/arcgis/rest/services/.../FeatureServer/0"
                  InputProps={{startAdornment:<InputAdornment position="start"><LinkIcon sx={{fontSize:14,color:"#9CA3AF"}}/></InputAdornment>}}
                  sx={{flex:1,"& .MuiInputBase-input":{fontSize:12}}}/>
                <Button variant="outlined" onClick={handleDetect} disabled={!restUrl||detecting} size="small" sx={{textTransform:"none",fontSize:11,whiteSpace:"nowrap",borderRadius:1.5,minWidth:90}}>
                  {detecting?<CircularProgress size={12}/>:"Detect fields"}
                </Button>
              </Box>
              {detecting&&<LinearProgress sx={{borderRadius:1}}/>}
              {detected&&<Box sx={{p:1.5,bgcolor:"#F0FDF4",borderRadius:1.5,border:"1px solid #BBF7D0"}}><Typography sx={{fontSize:11,fontWeight:700,color:C.success,mb:.5}}>✓ {detected.count} features — {detected.fields.length} fields detected</Typography><Box sx={{display:"flex",flexWrap:"wrap",gap:.5}}>{detected.fields.map(f=><Chip key={f} label={f} size="small" sx={{fontSize:10,height:18,bgcolor:"#DCFCE7",color:"#166534"}}/>)}</Box></Box>}
              {detErr&&<Box sx={{p:1.5,bgcolor:"#FEF2F2",borderRadius:1.5,border:"1px solid #FECACA"}}><Typography sx={{fontSize:11,color:C.danger}}>{detErr}</Typography></Box>}

              {/* Step 2: field config once layer chosen */}
              {hasLayer&&fields.length>0&&(
                <Box sx={{mt:.5}}>
                  <Box sx={{display:"flex",alignItems:"center",gap:1,mb:1.5}}>
                    <Box sx={{width:22,height:22,borderRadius:"50%",flexShrink:0,bgcolor:"#EFF6FF",display:"flex",alignItems:"center",justifyContent:"center"}}><Typography sx={{fontSize:11,fontWeight:800,color:C.primary}}>2</Typography></Box>
                    <Typography sx={{fontSize:12,fontWeight:700,color:C.text}}>Configure fields</Typography>
                  </Box>

                  {["serialChart","pieChart","list"].includes(lc.type)&&(
                    <FormControl size="small" fullWidth>
                      <InputLabel>Group by field</InputLabel>
                      <Select value={lc.groupByField||""} label="Group by field" onChange={e=>upd("groupByField",e.target.value)}>
                        {fields.map(f=><MenuItem key={f} value={f} sx={{fontSize:13}}>{f}</MenuItem>)}
                      </Select>
                    </FormControl>
                  )}
                  {lc.type==="gauge"&&<><FormControl size="small" fullWidth sx={{mb:1.5}}><InputLabel>Status field</InputLabel><Select value={lc.field||""} label="Status field" onChange={e=>upd("field",e.target.value)}>{fields.map(f=><MenuItem key={f} value={f} sx={{fontSize:13}}>{f}</MenuItem>)}</Select></FormControl><TextField label="Match value (e.g. Active)" value={lc.matchValue||""} onChange={e=>upd("matchValue",e.target.value)} size="small" fullWidth/></>}
                  {lc.type==="indicator"&&<><FormControl size="small" fullWidth sx={{mb:1.5}}><InputLabel>Aggregation</InputLabel><Select value={lc.aggregation||"count"} label="Aggregation" onChange={e=>upd("aggregation",e.target.value)}><MenuItem value="count">Count (total records)</MenuItem><MenuItem value="sum">Sum of field</MenuItem><MenuItem value="avg">Average</MenuItem></Select></FormControl><TextField label="Unit label (e.g. pipelines)" value={lc.unit||""} onChange={e=>upd("unit",e.target.value)} size="small" fullWidth/></>}
                  {lc.type==="table"&&<Box><Typography sx={{fontSize:11,color:C.muted,mb:.8}}>Click fields to include/exclude:</Typography><Box sx={{display:"flex",flexWrap:"wrap",gap:.5}}>{fields.map(f=>{const sel=lc.columns?.length?lc.columns.includes(f):true;return<Chip key={f} label={f} size="small" clickable onClick={()=>{const cur=lc.columns?.length?[...lc.columns]:[...fields];upd("columns",sel?cur.filter(x=>x!==f):[...cur,f]);}} sx={{fontSize:10,height:20,bgcolor:sel?"#EFF6FF":"#F9FAFB",color:sel?C.primary:"#9CA3AF",border:`1px solid ${sel?"#BFDBFE":"#E5E7EB"}`,fontWeight:sel?700:400}}/>;})}</Box></Box>}
                  {lc.type==="details"&&<Box><Typography sx={{fontSize:11,color:C.muted,mb:.8}}>Select fields to display:</Typography><Box sx={{display:"flex",flexWrap:"wrap",gap:.5}}>{fields.map(f=>{const sel=lc.detailFields?.length?lc.detailFields.includes(f):true;return<Chip key={f} label={f} size="small" clickable onClick={()=>{const cur=lc.detailFields?.length?[...lc.detailFields]:[...fields];upd("detailFields",sel?cur.filter(x=>x!==f):[...cur,f]);}} sx={{fontSize:10,height:20,bgcolor:sel?"#EFF6FF":"#F9FAFB",color:sel?C.primary:"#9CA3AF",border:`1px solid ${sel?"#BFDBFE":"#E5E7EB"}`,fontWeight:sel?700:400}}/>;})}</Box></Box>}
                </Box>
              )}
            </>)}
          </Box>
        )}

        {/* ── OPTIONS ─────────────────────────────────────── */}
        {tab===1&&(
          <Box sx={{p:2.5,display:"flex",flexDirection:"column",gap:2}}>
            {lc.type==="indicator"&&<Box><Typography sx={{fontSize:12,fontWeight:600,mb:1.5}}>Accent color</Typography><Box sx={{display:"flex",gap:1.5,flexWrap:"wrap"}}>{["#1565C0","#F59E0B","#16A34A","#7C3AED","#DC2626","#0891B2","#92400E","#374151"].map(col=><Box key={col} onClick={()=>upd("color",col)} sx={{width:32,height:32,borderRadius:1.5,bgcolor:col,cursor:"pointer",border:lc.color===col?"3px solid #1E293B":"2px solid transparent","&:hover":{transform:"scale(1.1)"},transition:"transform .12s"}}/>)}</Box></Box>}
            {lc.type==="pieChart"&&<><FormControlLabel control={<Switch checked={lc.donut!==false} size="small" onChange={e=>upd("donut",e.target.checked)}/>} label={<Typography sx={{fontSize:12}}>Donut style</Typography>}/><FormControlLabel control={<Switch checked={lc.showLegend!==false} size="small" onChange={e=>upd("showLegend",e.target.checked)}/>} label={<Typography sx={{fontSize:12}}>Show legend</Typography>}/></>}
            {lc.type==="table"&&<><FormControlLabel control={<Switch checked={lc.searchable!==false} size="small" onChange={e=>upd("searchable",e.target.checked)}/>} label={<Typography sx={{fontSize:12}}>Search bar</Typography>}/><FormControlLabel control={<Switch checked={lc.exportable!==false} size="small" onChange={e=>upd("exportable",e.target.checked)}/>} label={<Typography sx={{fontSize:12}}>Export CSV</Typography>}/><TextField label="Rows per page" type="number" value={lc.pageSize||5} onChange={e=>upd("pageSize",Number(e.target.value))} size="small" sx={{width:140}}/></>}
            {lc.type==="gauge"&&<><Box><Typography sx={{fontSize:12,fontWeight:600,mb:1}}>Warning below: <b style={{color:C.warning}}>{lc.thresholdWarning??60}%</b></Typography><Slider value={lc.thresholdWarning??60} onChange={(_,v)=>upd("thresholdWarning",v)} min={0} max={100} sx={{color:C.warning}}/></Box><Box><Typography sx={{fontSize:12,fontWeight:600,mb:1}}>Danger below: <b style={{color:C.danger}}>{lc.thresholdDanger??40}%</b></Typography><Slider value={lc.thresholdDanger??40} onChange={(_,v)=>upd("thresholdDanger",v)} min={0} max={100} sx={{color:C.danger}}/></Box></>}
            {!["indicator","pieChart","table","gauge"].includes(lc.type)&&<Typography sx={{fontSize:12,color:C.muted}}>No extra options for this widget.</Typography>}
          </Box>
        )}

        {/* ── REFRESH ─────────────────────────────────────── */}
        {tab===2&&(
          <Box sx={{p:2.5}}>
            <FormControl size="small" fullWidth>
              <InputLabel>Auto refresh</InputLabel>
              <Select value={lc.refreshInterval??60000} label="Auto refresh" onChange={e=>upd("refreshInterval",e.target.value)}>
                {REFRESH_OPT.map(o=><MenuItem key={o.value} value={o.value} sx={{fontSize:13}}>{o.label}</MenuItem>)}
              </Select>
            </FormControl>
          </Box>
        )}
      </DialogContent>

      <DialogActions sx={{px:2.5,py:1.5,borderTop:`1px solid ${C.border}`}}>
        <Button onClick={onClose} size="small" sx={{textTransform:"none",color:C.muted}}>Cancel</Button>
        <Button onClick={()=>onSave(lc)} variant="contained" size="small"
          disabled={needsLayer&&!hasLayer}
          sx={{textTransform:"none",bgcolor:C.primary,borderRadius:2,px:2.5,"&.Mui-disabled":{bgcolor:"#CBD5E1",color:"white"}}}>
          {needsLayer&&!hasLayer?"Select a layer first":"Apply"}
        </Button>
      </DialogActions>
    </Dialog>
  );
}

// =============================================================================
// PORTAL MANAGER
// =============================================================================
function PortalManagerDialog({open,portals,onClose,onSave}){
  const[list,setList]=useState(portals||[]);
  const[name,setName]=useState("");const[url,setUrl]=useState("");
  useEffect(()=>setList(portals||[]),[portals,open]);
  const add=()=>{if(!name.trim()||!url.trim())return;setList(p=>[...p,{id:`portal-${Date.now()}`,name:name.trim(),url:url.trim().replace(/\/$/,""),layers:[]}]);setName("");setUrl("");};
  return(
    <Dialog open={open} onClose={onClose} maxWidth="sm" fullWidth PaperProps={{sx:{borderRadius:3,overflow:"hidden"}}}>
      <Box sx={{bgcolor:C.topbar,color:"white",px:2.5,py:1.5,display:"flex",justifyContent:"space-between",alignItems:"center"}}>
        <Box><Typography sx={{fontWeight:700,fontSize:14}}>Portal Manager</Typography><Typography sx={{fontSize:11,opacity:.7}}>Add Esri Enterprise portals</Typography></Box>
        <IconButton onClick={onClose} size="small" sx={{color:"white"}}><CloseIcon/></IconButton>
      </Box>
      <DialogContent sx={{pt:2,pb:1}}>
        {list.map((p,i)=>(
          <Box key={p.id} sx={{display:"flex",alignItems:"center",gap:1.5,px:1.5,py:1,border:`1px solid ${C.border}`,borderRadius:2,mb:1,bgcolor:"#FAFBFC"}}>
            <PortalIcon sx={{fontSize:18,color:C.primary}}/>
            <Box sx={{flex:1,minWidth:0}}><Typography sx={{fontSize:13,fontWeight:700}}>{p.name}</Typography><Typography sx={{fontSize:10,color:C.muted,overflow:"hidden",textOverflow:"ellipsis",whiteSpace:"nowrap"}}>{p.url}</Typography></Box>
            <Box sx={{width:7,height:7,borderRadius:"50%",bgcolor:C.success}}/>
            <IconButton size="small" onClick={()=>setList(l=>l.filter((_,j)=>j!==i))} sx={{color:"#CBD5E1","&:hover":{color:C.danger}}}><DeleteIcon sx={{fontSize:15}}/></IconButton>
          </Box>
        ))}
        <Divider sx={{my:2}}/>
        <Box sx={{display:"flex",flexDirection:"column",gap:1.5}}>
          <TextField label="Portal name" value={name} onChange={e=>setName(e.target.value)} size="small" fullWidth placeholder="e.g. Production GIS Portal"/>
          <TextField label="Portal URL" value={url} onChange={e=>setUrl(e.target.value)} size="small" fullWidth placeholder="https://gis.company.com/portal"/>
          <Button variant="outlined" startIcon={<AddIcon/>} onClick={add} disabled={!name.trim()||!url.trim()} sx={{textTransform:"none",borderRadius:2,alignSelf:"flex-start",fontSize:12}}>Add Portal</Button>
        </Box>
      </DialogContent>
      <DialogActions sx={{px:2.5,py:1.5,borderTop:`1px solid ${C.border}`}}>
        <Button onClick={onClose} size="small" sx={{textTransform:"none",color:C.muted}}>Cancel</Button>
        <Button onClick={()=>onSave(list)} variant="contained" size="small" sx={{textTransform:"none",bgcolor:C.primary,borderRadius:2,px:2.5}}>Save</Button>
      </DialogActions>
    </Dialog>
  );
}

// =============================================================================
// EMPTY CANVAS
// =============================================================================
function EmptyCanvas({isAdmin}){
  return(
    <Box sx={{display:"flex",flexDirection:"column",alignItems:"center",justifyContent:"center",height:"100%",gap:2.5,userSelect:"none",px:3}}>
      <svg width="160" height="120" viewBox="0 0 160 120" fill="none">
        {[0,1,2,3].map(i=><line key={i} x1="16" y1={20+i*22} x2="144" y2={20+i*22} stroke="#E2E8F0" strokeWidth="1" strokeDasharray="4 3"/>)}
        <rect x="24" y="64" width="13" height="22" rx="2" fill="#BFDBFE"/><rect x="44" y="50" width="13" height="36" rx="2" fill="#3B82F6"/><rect x="64" y="56" width="13" height="30" rx="2" fill="#93C5FD"/><rect x="84" y="42" width="13" height="44" rx="2" fill="#1D4ED8"/>
        <circle cx="128" cy="60" r="20" fill="#EFF6FF" stroke="#DBEAFE" strokeWidth="1.5"/>
        <path d="M128 60 L128 40 A20 20 0 0 1 146 71 Z" fill="#3B82F6"/><path d="M128 60 L146 71 A20 20 0 0 1 110 71 Z" fill="#F59E0B"/>
        <circle cx="128" cy="60" r="9" fill="white"/>
      </svg>
      <Box sx={{textAlign:"center",maxWidth:320}}>
        <Typography sx={{fontWeight:700,fontSize:15,color:C.text,mb:.8}}>Your dashboard is empty</Typography>
        <Typography sx={{fontSize:13,color:C.muted,lineHeight:1.7}}>
          {isAdmin?<>Click a widget in the left panel to add it.<br/>Then choose your layer and configure it.</>:"No widgets have been added yet."}
        </Typography>
      </Box>
      {isAdmin&&<Box sx={{display:"flex",alignItems:"center",gap:.8,px:2,py:.8,borderRadius:2,bgcolor:"#EFF6FF",border:"1px solid #BFDBFE"}}><Typography sx={{fontSize:11,color:C.primary,fontWeight:600}}>← Click any widget type in the left panel</Typography></Box>}
    </Box>
  );
}

// =============================================================================
// LEFT PANEL  — ArcGIS style: Widgets tab (flat list) + Elements tab
// =============================================================================
function LeftPanel({isAdmin,configs,layout,onAddElement,onEditElement,onDeleteElement,portals,onOpenPortalManager,onClearAll}){
  const[mode,setMode]=useState("widgets");
  const widgetIds=layout.map(l=>l.i).filter(id=>configs[id]);

  const handlePick=type=>{
    if(!isAdmin)return;
    const def=WIDGET_TYPES[type],id=`el-${Date.now()}`;
    const maxY=layout.reduce((m,l)=>Math.max(m,l.y+l.h),0);
    const cfg={type,title:WIDGET_TYPES[type].label,layer:"",layerLabel:"",refreshInterval:60000,
      ...(type==="indicator"&&{aggregation:"count",unit:"",color:C.primary}),
      ...(type==="gauge"&&{field:"",matchValue:"",gaugeMin:0,gaugeMax:100,thresholdWarning:60,thresholdDanger:40,unit:"%"}),
      ...(type==="table"&&{columns:[],pageSize:5,searchable:true,exportable:true}),
      ...(type==="pieChart"&&{groupByField:"",donut:true,showLegend:true}),
      ...(type==="serialChart"&&{groupByField:""}),
      ...(type==="list"&&{groupByField:""}),
      ...(type==="details"&&{detailFields:[]}),
      ...(type==="map"&&{mapUrl:""}),
    };
    onAddElement(id,cfg,{i:id,x:0,y:maxY,w:def.defW,h:def.defH});
    setTimeout(()=>{onEditElement(id);setMode("elements");},80);
  };

  return(
    <Box sx={{width:240,flexShrink:0,height:"100%",display:"flex",flexDirection:"column",bgcolor:"#fff",borderRight:"1px solid #E5E7EB"}}>

      {/* Tabs */}
      <Box sx={{display:"flex",borderBottom:"1px solid #E5E7EB"}}>
        {[["widgets","Widgets"],["elements","Elements"]].map(([m,label])=>(
          <Box key={m} onClick={()=>setMode(m)}
            sx={{flex:1,py:1.3,textAlign:"center",fontSize:12.5,fontWeight:600,cursor:"pointer",
              color:mode===m?"#1D4ED8":"#9CA3AF",
              borderBottom:mode===m?"2px solid #1D4ED8":"2px solid transparent",
              transition:"all .15s","&:hover":{color:"#374151"}}}>
            {label}
            {m==="elements"&&widgetIds.length>0&&<Box component="span" sx={{ml:.7,px:.8,py:.1,borderRadius:6,bgcolor:"#EFF6FF",color:C.primary,fontSize:10,fontWeight:700}}>{widgetIds.length}</Box>}
          </Box>
        ))}
      </Box>

      {/* ── WIDGETS: flat list exactly like screenshot ── */}
      {mode==="widgets"&&(
        <Box sx={{flex:1,overflow:"auto"}}>
          {WIDGET_ORDER.map(type=>(
            <Box key={type} onClick={()=>handlePick(type)}
              sx={{display:"flex",alignItems:"center",gap:2,px:2.5,py:1.4,
                borderBottom:"1px solid #F3F4F6",cursor:isAdmin?"pointer":"default",bgcolor:"white",
                transition:"background .12s",
                "&:hover":isAdmin?{bgcolor:"#F9FAFB","& .wlabel":{color:"#1D4ED8"},"& .wicon":{color:"#1D4ED8"}}:{}}}>
              <Box className="wicon" sx={{color:"#6B7280",transition:"color .12s"}}><WIcon type={type} size={18}/></Box>
              <Typography className="wlabel" sx={{fontSize:13.5,color:"#374151",fontWeight:400,letterSpacing:"-.1px",transition:"color .12s"}}>
                {WIDGET_TYPES[type].label}
              </Typography>
            </Box>
          ))}
          {!isAdmin&&<Box sx={{p:2,textAlign:"center"}}><Typography sx={{fontSize:11,color:"#9CA3AF"}}>Viewer mode</Typography></Box>}
        </Box>
      )}

      {/* ── ELEMENTS: what's on canvas ────────────────── */}
      {mode==="elements"&&(
        <Box sx={{flex:1,overflow:"auto",display:"flex",flexDirection:"column"}}>
          {widgetIds.length===0?(
            <Box sx={{flex:1,display:"flex",flexDirection:"column",alignItems:"center",justifyContent:"center",gap:1.5,p:3,textAlign:"center"}}>
              <Box sx={{width:44,height:44,borderRadius:2,bgcolor:"#F3F4F6",display:"flex",alignItems:"center",justifyContent:"center"}}><LayersIcon sx={{fontSize:22,color:"#D1D5DB"}}/></Box>
              <Typography sx={{fontSize:12,color:"#9CA3AF"}}>No elements yet.<br/>Go to <b>Widgets</b> to add one.</Typography>
            </Box>
          ):(
            <Box sx={{p:1.5,display:"flex",flexDirection:"column",gap:.5}}>
              {widgetIds.map(id=>{
                const cfg=configs[id];if(!cfg)return null;
                const hasLayer=cfg.type==="map"?true:!!cfg.layer;
                return(
                  <Box key={id} sx={{display:"flex",alignItems:"center",gap:1.5,px:1.5,py:1,borderRadius:1.5,border:"1px solid #E5E7EB",bgcolor:"white",transition:"all .15s","&:hover":{bgcolor:"#F9FAFB","& .ea":{opacity:1}}}}>
                    <Box sx={{color:"#9CA3AF",flexShrink:0}}><WIcon type={cfg.type} size={16}/></Box>
                    <Box sx={{flex:1,minWidth:0}}>
                      <Typography sx={{fontSize:12,fontWeight:600,color:"#1F2937",overflow:"hidden",textOverflow:"ellipsis",whiteSpace:"nowrap"}}>{cfg.title||WIDGET_TYPES[cfg.type]?.label}</Typography>
                      <Typography sx={{fontSize:10,color:hasLayer?"#6B7280":C.warning,fontWeight:hasLayer?400:600}}>{hasLayer?(cfg.layerLabel||cfg.layer||"—"):"⚠ No layer"}</Typography>
                    </Box>
                    {isAdmin&&<Box className="ea" sx={{display:"flex",opacity:0,transition:"opacity .15s"}}>
                      <IconButton size="small" onClick={()=>onEditElement(id)} sx={{p:.3,color:"#9CA3AF","&:hover":{color:C.primary}}}><SettingsIcon sx={{fontSize:13}}/></IconButton>
                      <IconButton size="small" onClick={()=>onDeleteElement(id)} sx={{p:.3,color:"#9CA3AF","&:hover":{color:C.danger}}}><DeleteIcon sx={{fontSize:13}}/></IconButton>
                    </Box>}
                  </Box>
                );
              })}
            </Box>
          )}
          {isAdmin&&(
            <Box sx={{mt:"auto",p:1.5,borderTop:"1px solid #F3F4F6",display:"flex",flexDirection:"column",gap:.7}}>
              <Button size="small" startIcon={<PortalIcon sx={{fontSize:14}}/>} onClick={onOpenPortalManager} variant="outlined"
                sx={{textTransform:"none",fontSize:11,borderRadius:2,justifyContent:"flex-start",borderColor:"#E5E7EB",color:"#6B7280","&:hover":{borderColor:C.primary,color:C.primary}}}>
                Manage Portals
                {portals.length>0&&<Chip label={portals.length} size="small" sx={{ml:"auto",height:16,fontSize:9,bgcolor:"#EFF6FF",color:C.primary}}/>}
              </Button>
              <Button size="small" startIcon={<ResetIcon sx={{fontSize:14}}/>} onClick={onClearAll} variant="outlined"
                sx={{textTransform:"none",fontSize:11,borderRadius:2,justifyContent:"flex-start",borderColor:"#E5E7EB",color:"#6B7280","&:hover":{borderColor:C.danger,color:C.danger}}}>
                Clear all
              </Button>
            </Box>
          )}
        </Box>
      )}
    </Box>
  );
}

// =============================================================================
// MAIN DASHBOARD
// =============================================================================
export default function Dashboard({role="user",onBackToMap}){
  const isAdmin=role==="admin";
  const[configs,setConfigs]=useLS("bvg_configs",{});
  const[layout,setLayout]=useLS("bvg_layout",[]);
  const[portals,setPortals]=useLS("bvg_portals",[]);
  const[editId,setEditId]=useState(null);
  const[portalDlg,setPortalDlg]=useState(false);
  const[snack,setSnack]=useState({open:false,msg:"",sev:"success"});
  const snap=(msg,sev="success")=>setSnack({open:true,msg,sev});
  const widgetIds=layout.map(l=>l.i).filter(id=>configs[id]);

  const handleAdd=(id,cfg,li)=>{setConfigs(p=>({...p,[id]:cfg}));setLayout(p=>[...p,li]);};
  const handleDelete=id=>{setLayout(p=>p.filter(l=>l.i!==id));setConfigs(p=>{const n={...p};delete n[id];return n;});snap("Widget removed","info");};
  const handleSave=(id,nc)=>{setConfigs(p=>({...p,[id]:nc}));setEditId(null);snap("Widget configured");};
  const handleClearAll=()=>{setLayout([]);setConfigs({});snap("Dashboard cleared","info");};

  const renderCanvas=()=>{
    if(widgetIds.length===0)return<EmptyCanvas isAdmin={isAdmin}/>;
    if(!GridLayout)return(
      <Box sx={{display:"flex",flexWrap:"wrap",gap:2,p:2}}>
        {widgetIds.map(id=><Box key={id} sx={{width:"calc(50% - 8px)",minWidth:260,height:260}}><ManagedWidget widgetId={id} config={configs[id]} isAdmin={isAdmin} onEdit={()=>setEditId(id)} onDelete={()=>handleDelete(id)}/></Box>)}
      </Box>
    );
    return(
      <GridLayout layout={layout} cols={12} rowHeight={110} margin={[12,12]} containerPadding={[16,16]}
        onLayoutChange={nl=>{if(isAdmin)setLayout(nl);}}
        isDraggable={isAdmin} isResizable={isAdmin} draggableHandle=".drag-handle" style={{minHeight:"100%"}}>
        {widgetIds.map(id=><div key={id}><ManagedWidget widgetId={id} config={configs[id]} isAdmin={isAdmin} onEdit={()=>setEditId(id)} onDelete={()=>handleDelete(id)}/></div>)}
      </GridLayout>
    );
  };

  return(
    <Box sx={{display:"flex",flexDirection:"column",height:"100vh",width:"100vw",bgcolor:C.bg,overflow:"hidden"}}>

      {/* TOP BAR */}
      <Box sx={{height:50,flexShrink:0,bgcolor:C.topbar,color:"white",display:"flex",alignItems:"center",px:2,gap:2,boxShadow:"0 1px 4px rgba(0,0,0,.3)"}}>
        <Box sx={{width:34,height:34,borderRadius:1.5,bgcolor:C.accent,display:"flex",alignItems:"center",justifyContent:"center",flexShrink:0}}><LayersIcon sx={{fontSize:18,color:"white"}}/></Box>
        <Typography sx={{fontWeight:700,fontSize:15,letterSpacing:"-.3px"}}>Gas Data Analysis</Typography>
        <Box sx={{flex:1}}/>
        {portals.slice(0,2).map(p=><Chip key={p.id} label={p.name} size="small" sx={{fontSize:10,height:22,bgcolor:"rgba(255,255,255,.1)",color:"rgba(255,255,255,.8)",border:"1px solid rgba(255,255,255,.15)"}}/>)}
        <Chip icon={isAdmin?<AdminIcon sx={{fontSize:"13px !important",color:`${C.accent} !important`}}/>:<PersonIcon sx={{fontSize:"13px !important"}}/>} label={isAdmin?"Admin":"Viewer"} size="small" sx={{fontSize:11,height:24,bgcolor:"rgba(255,255,255,.1)",color:"white",border:"1px solid rgba(255,255,255,.15)",fontWeight:600}}/>
        {isAdmin&&<MuiTooltip title="Save layout"><IconButton size="small" onClick={()=>snap("Layout saved")} sx={{color:"rgba(255,255,255,.7)","&:hover":{color:"white"}}}><SaveIcon sx={{fontSize:18}}/></IconButton></MuiTooltip>}
        <Divider orientation="vertical" flexItem sx={{borderColor:"rgba(255,255,255,.15)"}}/>
        <Button startIcon={<MapIcon sx={{fontSize:15}}/>} onClick={onBackToMap} size="small" sx={{textTransform:"none",fontSize:12,color:"rgba(255,255,255,.8)","&:hover":{bgcolor:"rgba(255,255,255,.1)",color:"white"},borderRadius:2}}>Back to Map</Button>
      </Box>

      {/* BODY */}
      <Box sx={{flex:1,display:"flex",overflow:"hidden"}}>
        <LeftPanel isAdmin={isAdmin} configs={configs} layout={layout}
          onAddElement={handleAdd} onEditElement={setEditId} onDeleteElement={handleDelete}
          portals={portals} onOpenPortalManager={()=>setPortalDlg(true)} onClearAll={handleClearAll}/>
        <Box sx={{flex:1,overflow:"auto",bgcolor:C.bg}}>{renderCanvas()}</Box>
      </Box>

      {editId&&configs[editId]&&<ConfigDialog open={Boolean(editId)} config={configs[editId]} onClose={()=>setEditId(null)} onSave={nc=>handleSave(editId,nc)} portals={portals}/>}
      <PortalManagerDialog open={portalDlg} portals={portals} onClose={()=>setPortalDlg(false)} onSave={list=>{setPortals(list);setPortalDlg(false);snap(`${list.length} portal(s) saved`);}}/>
      <Snackbar open={snack.open} autoHideDuration={2500} onClose={()=>setSnack(s=>({...s,open:false}))} anchorOrigin={{vertical:"bottom",horizontal:"right"}}>
        <Alert severity={snack.sev} onClose={()=>setSnack(s=>({...s,open:false}))} sx={{fontSize:13,borderRadius:2}}>{snack.msg}</Alert>
      </Snackbar>
    </Box>
  );
}